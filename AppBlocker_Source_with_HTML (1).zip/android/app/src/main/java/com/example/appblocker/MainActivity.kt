package com.example.appblocker

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*

class MainActivity : Activity() {
    private data class AppItem(val pkg: String, val label: String, val icon: Drawable)

    private val prefs by lazy { getSharedPreferences("rules", MODE_PRIVATE) }
    private val selected = mutableSetOf<String>()      // 차단 ON 인 앱 패키지
    private val allApps = mutableListOf<AppItem>()      // 기기에서 자동 인식한 앱 전체
    private val shown = mutableListOf<AppItem>()        // 검색 필터 적용 결과
    private val dayChecks = mutableListOf<CheckBox>()
    private var query = ""

    private lateinit var adapter: AppAdapter
    private lateinit var statusText: TextView
    private lateinit var countText: TextView
    private lateinit var startTime: EditText
    private lateinit var endTime: EditText

    // 앱이 설치/삭제되면 목록을 자동으로 다시 인식
    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { loadApps() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN)
        selected.addAll(prefs.getStringSet("packages", emptySet()) ?: emptySet())

        val list = ListView(this).apply {
            divider = null
            addHeaderView(buildHeader(), null, false)
        }
        adapter = AppAdapter()
        list.adapter = adapter
        setContentView(list)
    }

    override fun onResume() {
        super.onResume()
        updateServiceStatus()
        loadApps()
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addDataScheme("package")
        }
        registerReceiver(pkgReceiver, filter)
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(pkgReceiver) } catch (_: Exception) {}
    }

    private fun buildHeader(): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(8))
        }
        box.addView(TextView(this).apply { text = "AppBlocker"; textSize = 26f })
        box.addView(TextView(this).apply {
            text = "설치된 앱을 자동으로 찾아줘. 스위치로 앱별 차단을 켜고 꺼."
            textSize = 15f
        })
        statusText = TextView(this).apply { textSize = 14f; setPadding(0, dp(8), 0, 0) }
        box.addView(statusText)
        box.addView(Button(this).apply {
            text = "① 접근성 차단 서비스 켜기"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        box.addView(TextView(this).apply { text = "② 차단할 앱"; textSize = 19f; setPadding(0, dp(12), 0, dp(4)) })
        countText = TextView(this).apply { textSize = 13f; setTextColor(Color.GRAY) }
        box.addView(countText)
        box.addView(EditText(this).apply {
            hint = "앱 이름 검색"; setSingleLine(true)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    query = s?.toString()?.trim() ?: ""
                    applyFilter()
                }
            })
        })
        return box.also { addSettingsFooterTo(it) }
    }

    // 요일/시간 설정은 목록 위쪽 헤더 영역에 둔다
    private fun addSettingsFooterTo(box: LinearLayout) {
        box.addView(TextView(this).apply { text = "③ 적용할 요일"; textSize = 19f; setPadding(0, dp(16), 0, dp(4)) })
        val days = listOf("월", "화", "수", "목", "금", "토", "일")
        val dayRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        days.forEachIndexed { index, name ->
            val c = CheckBox(this).apply {
                text = name
                isChecked = prefs.getBoolean("day_$index", index < 5)
            }
            dayChecks.add(c); dayRow.addView(c)
        }
        box.addView(dayRow)
        box.addView(TextView(this).apply { text = "④ 차단 시간 (24시간제, 예: 16:00)"; setPadding(0, dp(8), 0, dp(4)) })
        startTime = EditText(this).apply {
            hint = "시작 시간 HH:MM"; setSingleLine(true)
            setText(prefs.getString("start", "16:00"))
        }
        endTime = EditText(this).apply {
            hint = "종료 시간 HH:MM"; setSingleLine(true)
            setText(prefs.getString("end", "18:00"))
        }
        box.addView(startTime); box.addView(endTime)
        box.addView(Button(this).apply { text = "요일/시간 저장"; setOnClickListener { saveSchedule() } })
        box.addView(Button(this).apply {
            text = "이 앱의 접근성 설정 열기"
            setOnClickListener {
                val i = Intent(Settings.ACTION_ACCESSIBILITY_DETAILS_SETTINGS)
                i.data = Uri.parse("package:$packageName")
                try { startActivity(i) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            }
        })
        box.addView(TextView(this).apply {
            text = "앱 스위치는 누르는 즉시 저장돼. 차단은 접근성 서비스가 켜져 있을 때만 작동해."
            textSize = 13f; setTextColor(Color.GRAY); setPadding(0, dp(8), 0, dp(8))
        })
    }

    private fun updateServiceStatus() {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains(packageName) == true
        statusText.text = if (enabled) "● 차단 서비스 켜짐" else "● 차단 서비스 꺼짐 — 아래 버튼으로 켜줘"
        statusText.setTextColor(if (enabled) Color.rgb(0, 128, 0) else Color.rgb(200, 0, 0))
    }

    /** 기기에 설치된 실행 가능한 앱을 자동 인식 */
    private fun loadApps() {
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val found = packageManager.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { AppItem(it.activityInfo.packageName, it.loadLabel(packageManager).toString(), it.loadIcon(packageManager)) }
        allApps.clear(); allApps.addAll(found)
        applyFilter()
    }

    private fun applyFilter() {
        val q = query.lowercase()
        val filtered = allApps.filter { q.isEmpty() || it.label.lowercase().contains(q) || it.pkg.lowercase().contains(q) }
            .sortedWith(compareByDescending<AppItem> { it.pkg in selected }.thenBy { it.label.lowercase() })
        shown.clear(); shown.addAll(filtered)
        adapter.notifyDataSetChanged()
        updateCount()
    }

    private fun updateCount() {
        val onCount = allApps.count { it.pkg in selected }
        countText.text = "인식된 앱 ${allApps.size}개 · 차단 켜짐 ${onCount}개"
    }

    private fun setBlocked(pkg: String, on: Boolean) {
        if (on) selected.add(pkg) else selected.remove(pkg)
        prefs.edit().putStringSet("packages", selected.toSet()).apply()
        updateCount()
    }

    private inner class AppAdapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(position: Int) = shown[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row: LinearLayout
            val icon: ImageView
            val name: TextView
            val sw: Switch
            if (convertView == null) {
                row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(16), dp(6), dp(16), dp(6))
                }
                icon = ImageView(this@MainActivity)
                row.addView(icon, LinearLayout.LayoutParams(dp(40), dp(40)))
                name = TextView(this@MainActivity).apply { textSize = 16f; setPadding(dp(12), 0, dp(12), 0) }
                row.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                sw = Switch(this@MainActivity)
                row.addView(sw)
                row.tag = Triple(icon, name, sw)
            } else {
                row = convertView as LinearLayout
                @Suppress("UNCHECKED_CAST")
                val t = row.tag as Triple<ImageView, TextView, Switch>
                icon = t.first; name = t.second; sw = t.third
            }
            val item = shown[position]
            icon.setImageDrawable(item.icon)
            name.text = item.label
            sw.setOnCheckedChangeListener(null)
            sw.isChecked = item.pkg in selected
            sw.setOnCheckedChangeListener { _, checked -> setBlocked(item.pkg, checked) }
            return row
        }
    }

    private fun saveSchedule() {
        val start = startTime.text.toString().trim()
        val end = endTime.text.toString().trim()
        if (!validTime(start) || !validTime(end) || start == end) {
            Toast.makeText(this, "시간을 HH:MM 형식으로 입력하고 시작/종료를 다르게 설정해.", Toast.LENGTH_LONG).show()
            return
        }
        val editor = prefs.edit().putString("start", start).putString("end", end)
        dayChecks.forEachIndexed { i, cb -> editor.putBoolean("day_$i", cb.isChecked) }
        editor.apply()
        Toast.makeText(this, "요일/시간을 저장했어.", Toast.LENGTH_SHORT).show()
    }

    private fun validTime(value: String): Boolean =
        Regex("^([01]\\d|2[0-3]):[0-5]\\d$").matches(value)
}
